import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Plane, Clock, MapPin, Calendar, Users, Star } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function FlightsTab() {
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'upcoming' | 'completed'>('all');

  const bookings = [
    {
      id: '1',
      airline: 'Bangladesh Airlines',
      flightNumber: 'BG 145',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Dubai',
      toCode: 'DXB',
      departDate: '2024-12-25',
      departTime: '10:30 AM',
      arrivalTime: '2:45 PM',
      duration: '4h 15m',
      status: 'upcoming',
      passengers: 2,
      bookingRef: 'BG145DAC',
      price: '৳45,000',
      rating: 4.5,
    },
    {
      id: '2',
      airline: 'US-Bangla Airlines',
      flightNumber: 'BS 311',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Bangkok',
      toCode: 'BKK',
      departDate: '2024-11-15',
      departTime: '11:20 PM',
      arrivalTime: '5:30 AM+1',
      duration: '3h 10m',
      status: 'completed',
      passengers: 1,
      bookingRef: 'BS311DAC',
      price: '৳25,000',
      rating: 4.2,
    },
    {
      id: '3',
      airline: 'Biman Bangladesh',
      flightNumber: 'BG 007',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Singapore',
      toCode: 'SIN',
      departDate: '2025-01-10',
      departTime: '8:15 AM',
      arrivalTime: '3:20 PM',
      duration: '4h 5m',
      status: 'upcoming',
      passengers: 3,
      bookingRef: 'BG007DAC',
      price: '৳38,000',
      rating: 4.7,
    },
  ];

  const filteredBookings = bookings.filter(booking => 
    selectedFilter === 'all' ? true : booking.status === selectedFilter
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming': return '#059669';
      case 'completed': return '#6B7280';
      default: return '#F97316';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'upcoming': return 'Upcoming';
      case 'completed': return 'Completed';
      default: return 'In Progress';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1E40AF', '#3B82F6']}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>My Flights</Text>
        <Text style={styles.headerSubtitle}>Manage your bookings</Text>
      </LinearGradient>

      <View style={styles.filterContainer}>
        <TouchableOpacity
          style={[styles.filterButton, selectedFilter === 'all' && styles.filterButtonActive]}
          onPress={() => setSelectedFilter('all')}
        >
          <Text style={[styles.filterText, selectedFilter === 'all' && styles.filterTextActive]}>
            All Flights
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.filterButton, selectedFilter === 'upcoming' && styles.filterButtonActive]}
          onPress={() => setSelectedFilter('upcoming')}
        >
          <Text style={[styles.filterText, selectedFilter === 'upcoming' && styles.filterTextActive]}>
            Upcoming
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.filterButton, selectedFilter === 'completed' && styles.filterButtonActive]}
          onPress={() => setSelectedFilter('completed')}
        >
          <Text style={[styles.filterText, selectedFilter === 'completed' && styles.filterTextActive]}>
            Completed
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {filteredBookings.map((booking) => (
          <TouchableOpacity key={booking.id} style={styles.bookingCard}>
            <View style={styles.bookingHeader}>
              <View style={styles.airlineInfo}>
                <Text style={styles.airlineName}>{booking.airline}</Text>
                <Text style={styles.flightNumber}>{booking.flightNumber}</Text>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: getStatusColor(booking.status) + '20' }]}>
                <Text style={[styles.statusText, { color: getStatusColor(booking.status) }]}>
                  {getStatusText(booking.status)}
                </Text>
              </View>
            </View>

            <View style={styles.flightRoute}>
              <View style={styles.routePoint}>
                <Text style={styles.cityCode}>{booking.fromCode}</Text>
                <Text style={styles.cityName}>{booking.from}</Text>
                <Text style={styles.timeText}>{booking.departTime}</Text>
              </View>
              
              <View style={styles.routeMiddle}>
                <View style={styles.routeLine} />
                <Plane size={20} color="#1E40AF" style={styles.planeIcon} />
                <View style={styles.routeLine} />
              </View>

              <View style={styles.routePoint}>
                <Text style={styles.cityCode}>{booking.toCode}</Text>
                <Text style={styles.cityName}>{booking.to}</Text>
                <Text style={styles.timeText}>{booking.arrivalTime}</Text>
              </View>
            </View>

            <View style={styles.flightDetails}>
              <View style={styles.detailItem}>
                <Calendar size={16} color="#6B7280" />
                <Text style={styles.detailText}>{booking.departDate}</Text>
              </View>
              <View style={styles.detailItem}>
                <Clock size={16} color="#6B7280" />
                <Text style={styles.detailText}>{booking.duration}</Text>
              </View>
              <View style={styles.detailItem}>
                <Users size={16} color="#6B7280" />
                <Text style={styles.detailText}>{booking.passengers} Passenger{booking.passengers > 1 ? 's' : ''}</Text>
              </View>
            </View>

            <View style={styles.bookingFooter}>
              <View style={styles.priceSection}>
                <Text style={styles.bookingRef}>Ref: {booking.bookingRef}</Text>
                <Text style={styles.price}>{booking.price}</Text>
              </View>
              <View style={styles.ratingSection}>
                <Star size={14} color="#F59E0B" fill="#F59E0B" />
                <Text style={styles.rating}>{booking.rating}</Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}

        {filteredBookings.length === 0 && (
          <View style={styles.emptyState}>
            <Plane size={48} color="#9CA3AF" />
            <Text style={styles.emptyTitle}>No flights found</Text>
            <Text style={styles.emptyDescription}>
              You don't have any {selectedFilter === 'all' ? '' : selectedFilter} flights yet.
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 24,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#E0E7FF',
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 12,
  },
  filterButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  filterButtonActive: {
    backgroundColor: '#1E40AF',
  },
  filterText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  filterTextActive: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  bookingCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  airlineInfo: {
    flex: 1,
  },
  airlineName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 2,
  },
  flightNumber: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  flightRoute: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  routePoint: {
    flex: 1,
    alignItems: 'center',
  },
  cityCode: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 2,
  },
  cityName: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  timeText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1E40AF',
  },
  routeMiddle: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  routeLine: {
    flex: 1,
    height: 2,
    backgroundColor: '#E5E7EB',
  },
  planeIcon: {
    marginHorizontal: 8,
  },
  flightDetails: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  detailText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  bookingFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  priceSection: {
    flex: 1,
  },
  bookingRef: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 2,
  },
  price: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#059669',
  },
  ratingSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rating: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 20,
  },
});