import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Plane, Clock, MapPin, CircleAlert as AlertCircle, CircleCheck as CheckCircle, Circle as XCircle } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function StatusTab() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState('today');

  const flightStatus = [
    {
      id: '1',
      flightNumber: 'BG 145',
      airline: 'Bangladesh Airlines',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Dubai',
      toCode: 'DXB',
      scheduledDeparture: '10:30 AM',
      actualDeparture: '10:45 AM',
      scheduledArrival: '2:45 PM',
      estimatedArrival: '3:00 PM',
      status: 'delayed',
      gate: 'A12',
      terminal: '1',
      delay: '15 min',
    },
    {
      id: '2',
      flightNumber: 'BS 311',
      airline: 'US-Bangla Airlines',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Bangkok',
      toCode: 'BKK',
      scheduledDeparture: '11:20 PM',
      actualDeparture: '11:20 PM',
      scheduledArrival: '5:30 AM+1',
      estimatedArrival: '5:30 AM+1',
      status: 'on-time',
      gate: 'B08',
      terminal: '2',
      delay: null,
    },
    {
      id: '3',
      flightNumber: 'BG 007',
      airline: 'Biman Bangladesh',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Singapore',
      toCode: 'SIN',
      scheduledDeparture: '8:15 AM',
      actualDeparture: null,
      scheduledArrival: '3:20 PM',
      estimatedArrival: null,
      status: 'cancelled',
      gate: null,
      terminal: '1',
      delay: null,
    },
  ];

  const filteredFlights = flightStatus.filter(flight =>
    flight.flightNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
    flight.airline.toLowerCase().includes(searchQuery.toLowerCase()) ||
    flight.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
    flight.to.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'on-time':
        return <CheckCircle size={20} color="#059669" />;
      case 'delayed':
        return <AlertCircle size={20} color="#F97316" />;
      case 'cancelled':
        return <XCircle size={20} color="#DC2626" />;
      default:
        return <Clock size={20} color="#6B7280" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'on-time': return '#059669';
      case 'delayed': return '#F97316';
      case 'cancelled': return '#DC2626';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'on-time': return 'On Time';
      case 'delayed': return 'Delayed';
      case 'cancelled': return 'Cancelled';
      default: return 'Unknown';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1E40AF', '#3B82F6']}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>Flight Status</Text>
        <Text style={styles.headerSubtitle}>Real-time flight information</Text>
      </LinearGradient>

      <View style={styles.searchContainer}>
        <View style={styles.searchInputContainer}>
          <Search size={20} color="#6B7280" />
          <TextInput
            style={styles.searchInput}
            placeholder="Search flight number, airline, or city"
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholderTextColor="#9CA3AF"
          />
        </View>
      </View>

      <View style={styles.dateFilters}>
        <TouchableOpacity
          style={[styles.dateFilter, selectedDate === 'today' && styles.dateFilterActive]}
          onPress={() => setSelectedDate('today')}
        >
          <Text style={[styles.dateFilterText, selectedDate === 'today' && styles.dateFilterTextActive]}>
            Today
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.dateFilter, selectedDate === 'tomorrow' && styles.dateFilterActive]}
          onPress={() => setSelectedDate('tomorrow')}
        >
          <Text style={[styles.dateFilterText, selectedDate === 'tomorrow' && styles.dateFilterTextActive]}>
            Tomorrow
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {filteredFlights.map((flight) => (
          <TouchableOpacity key={flight.id} style={styles.flightCard}>
            <View style={styles.flightHeader}>
              <View style={styles.flightInfo}>
                <Text style={styles.flightNumber}>{flight.flightNumber}</Text>
                <Text style={styles.airline}>{flight.airline}</Text>
              </View>
              <View style={[styles.statusContainer, { backgroundColor: getStatusColor(flight.status) + '20' }]}>
                {getStatusIcon(flight.status)}
                <Text style={[styles.statusText, { color: getStatusColor(flight.status) }]}>
                  {getStatusText(flight.status)}
                </Text>
              </View>
            </View>

            <View style={styles.routeContainer}>
              <View style={styles.routePoint}>
                <Text style={styles.cityCode}>{flight.fromCode}</Text>
                <Text style={styles.cityName}>{flight.from}</Text>
              </View>
              
              <View style={styles.routeMiddle}>
                <View style={styles.routeLine} />
                <Plane size={16} color="#1E40AF" />
                <View style={styles.routeLine} />
              </View>

              <View style={styles.routePoint}>
                <Text style={styles.cityCode}>{flight.toCode}</Text>
                <Text style={styles.cityName}>{flight.to}</Text>
              </View>
            </View>

            <View style={styles.timeContainer}>
              <View style={styles.timeSection}>
                <Text style={styles.timeLabel}>Departure</Text>
                <Text style={styles.scheduledTime}>{flight.scheduledDeparture}</Text>
                {flight.actualDeparture && flight.actualDeparture !== flight.scheduledDeparture && (
                  <Text style={styles.actualTime}>Actual: {flight.actualDeparture}</Text>
                )}
              </View>
              <View style={styles.timeSection}>
                <Text style={styles.timeLabel}>Arrival</Text>
                <Text style={styles.scheduledTime}>{flight.scheduledArrival}</Text>
                {flight.estimatedArrival && flight.estimatedArrival !== flight.scheduledArrival && (
                  <Text style={styles.estimatedTime}>Est: {flight.estimatedArrival}</Text>
                )}
              </View>
            </View>

            <View style={styles.flightDetails}>
              {flight.gate && (
                <View style={styles.detailItem}>
                  <Text style={styles.detailLabel}>Gate:</Text>
                  <Text style={styles.detailValue}>{flight.gate}</Text>
                </View>
              )}
              {flight.terminal && (
                <View style={styles.detailItem}>
                  <Text style={styles.detailLabel}>Terminal:</Text>
                  <Text style={styles.detailValue}>{flight.terminal}</Text>
                </View>
              )}
              {flight.delay && (
                <View style={styles.detailItem}>
                  <Text style={styles.detailLabel}>Delay:</Text>
                  <Text style={[styles.detailValue, { color: '#F97316' }]}>{flight.delay}</Text>
                </View>
              )}
            </View>
          </TouchableOpacity>
        ))}

        {filteredFlights.length === 0 && (
          <View style={styles.emptyState}>
            <Search size={48} color="#9CA3AF" />
            <Text style={styles.emptyTitle}>No flights found</Text>
            <Text style={styles.emptyDescription}>
              Try searching with a different flight number or airline.
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 24,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#E0E7FF',
  },
  searchContainer: {
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  searchInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  searchInput: {
    flex: 1,
    marginLeft: 12,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#1F2937',
  },
  dateFilters: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingBottom: 16,
    gap: 12,
  },
  dateFilter: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  dateFilterActive: {
    backgroundColor: '#1E40AF',
  },
  dateFilterText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  dateFilterTextActive: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  flightCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  flightHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  flightInfo: {
    flex: 1,
  },
  flightNumber: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 2,
  },
  airline: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 6,
  },
  statusText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
  },
  routeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  routePoint: {
    flex: 1,
    alignItems: 'center',
  },
  cityCode: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 2,
  },
  cityName: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  routeMiddle: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  routeLine: {
    flex: 1,
    height: 2,
    backgroundColor: '#E5E7EB',
  },
  timeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  timeSection: {
    flex: 1,
    alignItems: 'center',
  },
  timeLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 4,
  },
  scheduledTime: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  actualTime: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#F97316',
    marginTop: 2,
  },
  estimatedTime: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#059669',
    marginTop: 2,
  },
  flightDetails: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  detailItem: {
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 2,
  },
  detailValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 18,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#9CA3AF',
    textAlign: 'center',
    lineHeight: 20,
  },
});