import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ImageBackground } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Tag, Clock, MapPin, Plane, Star, Calendar } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function DealsTab() {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'domestic' | 'international'>('all');

  const deals = [
    {
      id: '1',
      title: 'Dubai Special Offer',
      subtitle: 'Limited Time Deal',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Dubai',
      toCode: 'DXB',
      originalPrice: '৳65,000',
      discountPrice: '৳45,000',
      discount: '31% OFF',
      validUntil: '2024-12-31',
      image: 'https://images.pexels.com/photos/162031/dubai-tower-arab-khalifa-162031.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'international',
      rating: 4.5,
      savings: '৳20,000',
    },
    {
      id: '2',
      title: 'Bangkok Adventure',
      subtitle: 'Early Bird Special',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Bangkok',
      toCode: 'BKK',
      originalPrice: '৳35,000',
      discountPrice: '৳25,000',
      discount: '29% OFF',
      validUntil: '2024-12-25',
      image: 'https://images.pexels.com/photos/2670273/pexels-photo-2670273.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'international',
      rating: 4.3,
      savings: '৳10,000',
    },
    {
      id: '3',
      title: 'Cox\'s Bazar Weekend',
      subtitle: 'Domestic Special',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Cox\'s Bazar',
      toCode: 'CXB',
      originalPrice: '৳8,000',
      discountPrice: '৳5,500',
      discount: '31% OFF',
      validUntil: '2025-01-15',
      image: 'https://images.pexels.com/photos/457882/pexels-photo-457882.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'domestic',
      rating: 4.7,
      savings: '৳2,500',
    },
    {
      id: '4',
      title: 'Singapore Gateway',
      subtitle: 'Premium Deal',
      from: 'Dhaka',
      fromCode: 'DAC',
      to: 'Singapore',
      toCode: 'SIN',
      originalPrice: '৳55,000',
      discountPrice: '৳38,000',
      discount: '31% OFF',
      validUntil: '2025-01-31',
      image: 'https://images.pexels.com/photos/2169434/pexels-photo-2169434.jpeg?auto=compress&cs=tinysrgb&w=400',
      category: 'international',
      rating: 4.6,
      savings: '৳17,000',
    },
  ];

  const filteredDeals = deals.filter(deal => 
    selectedCategory === 'all' ? true : deal.category === selectedCategory
  );

  const categories = [
    { key: 'all', label: 'All Deals' },
    { key: 'domestic', label: 'Domestic' },
    { key: 'international', label: 'International' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1E40AF', '#3B82F6']}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>Special Deals</Text>
        <Text style={styles.headerSubtitle}>Save big on your next trip</Text>
      </LinearGradient>

      <View style={styles.categoryContainer}>
        {categories.map((category) => (
          <TouchableOpacity
            key={category.key}
            style={[
              styles.categoryButton,
              selectedCategory === category.key && styles.categoryButtonActive
            ]}
            onPress={() => setSelectedCategory(category.key as any)}
          >
            <Text style={[
              styles.categoryText,
              selectedCategory === category.key && styles.categoryTextActive
            ]}>
              {category.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.statsCard}>
          <View style={styles.statItem}>
            <Tag size={24} color="#059669" />
            <Text style={styles.statNumber}>15+</Text>
            <Text style={styles.statLabel}>Active Deals</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Star size={24} color="#F59E0B" />
            <Text style={styles.statNumber}>4.5★</Text>
            <Text style={styles.statLabel}>Average Rating</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Clock size={24} color="#F97316" />
            <Text style={styles.statNumber}>24h</Text>
            <Text style={styles.statLabel}>Deal Updates</Text>
          </View>
        </View>

        {filteredDeals.map((deal) => (
          <TouchableOpacity key={deal.id} style={styles.dealCard}>
            <ImageBackground 
              source={{ uri: deal.image }} 
              style={styles.dealImage}
              imageStyle={styles.dealImageStyle}
            >
              <LinearGradient
                colors={['transparent', 'rgba(0,0,0,0.8)']}
                style={styles.imageOverlay}
              >
                <View style={styles.discountBadge}>
                  <Text style={styles.discountText}>{deal.discount}</Text>
                </View>
                <View style={styles.imageContent}>
                  <Text style={styles.dealTitle}>{deal.title}</Text>
                  <Text style={styles.dealSubtitle}>{deal.subtitle}</Text>
                </View>
              </LinearGradient>
            </ImageBackground>

            <View style={styles.dealInfo}>
              <View style={styles.routeSection}>
                <View style={styles.routeInfo}>
                  <Text style={styles.routeCode}>{deal.fromCode}</Text>
                  <Text style={styles.routeCity}>{deal.from}</Text>
                </View>
                <View style={styles.routeArrow}>
                  <Plane size={16} color="#1E40AF" />
                </View>
                <View style={styles.routeInfo}>
                  <Text style={styles.routeCode}>{deal.toCode}</Text>
                  <Text style={styles.routeCity}>{deal.to}</Text>
                </View>
              </View>

              <View style={styles.priceSection}>
                <View style={styles.priceInfo}>
                  <Text style={styles.originalPrice}>{deal.originalPrice}</Text>
                  <Text style={styles.discountPrice}>{deal.discountPrice}</Text>
                  <Text style={styles.savings}>Save {deal.savings}</Text>
                </View>
                <View style={styles.ratingSection}>
                  <Star size={14} color="#F59E0B" fill="#F59E0B" />
                  <Text style={styles.rating}>{deal.rating}</Text>
                </View>
              </View>

              <View style={styles.dealFooter}>
                <View style={styles.validityInfo}>
                  <Calendar size={14} color="#6B7280" />
                  <Text style={styles.validityText}>Valid until {deal.validUntil}</Text>
                </View>
                <TouchableOpacity style={styles.bookButton}>
                  <Text style={styles.bookButtonText}>Book Now</Text>
                </TouchableOpacity>
              </View>
            </View>
          </TouchableOpacity>
        ))}

        <View style={styles.newsletterCard}>
          <Text style={styles.newsletterTitle}>Never Miss a Deal!</Text>
          <Text style={styles.newsletterDescription}>
            Get notified about exclusive offers and limited-time deals
          </Text>
          <TouchableOpacity style={styles.subscribeButton}>
            <Text style={styles.subscribeButtonText}>Subscribe to Alerts</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 24,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#E0E7FF',
  },
  categoryContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 16,
    gap: 12,
  },
  categoryButton: {
    flex: 1,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  categoryButtonActive: {
    backgroundColor: '#1E40AF',
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#6B7280',
  },
  categoryTextActive: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  statsCard: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginTop: 8,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    textAlign: 'center',
  },
  statDivider: {
    width: 1,
    backgroundColor: '#E5E7EB',
    marginHorizontal: 16,
  },
  dealCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    marginBottom: 20,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  dealImage: {
    height: 160,
  },
  dealImageStyle: {
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  imageOverlay: {
    flex: 1,
    justifyContent: 'space-between',
    padding: 16,
  },
  discountBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#DC2626',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  discountText: {
    fontSize: 12,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  imageContent: {
    alignSelf: 'flex-start',
  },
  dealTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  dealSubtitle: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#E0E7FF',
  },
  dealInfo: {
    padding: 20,
  },
  routeSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  routeInfo: {
    alignItems: 'center',
    flex: 1,
  },
  routeCode: {
    fontSize: 18,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 2,
  },
  routeCity: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  routeArrow: {
    paddingHorizontal: 20,
  },
  priceSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    marginBottom: 16,
  },
  priceInfo: {
    flex: 1,
  },
  originalPrice: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    textDecorationLine: 'line-through',
    marginBottom: 4,
  },
  discountPrice: {
    fontSize: 24,
    fontFamily: 'Inter-Bold',
    color: '#059669',
    marginBottom: 2,
  },
  savings: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#F97316',
  },
  ratingSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  rating: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  dealFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: '#F1F5F9',
  },
  validityInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },
  validityText: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  bookButton: {
    backgroundColor: '#1E40AF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  bookButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
  },
  newsletterCard: {
    backgroundColor: '#1E40AF',
    borderRadius: 16,
    padding: 24,
    alignItems: 'center',
    marginBottom: 32,
  },
  newsletterTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  newsletterDescription: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#E0E7FF',
    textAlign: 'center',
    marginBottom: 20,
    lineHeight: 20,
  },
  subscribeButton: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  subscribeButtonText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1E40AF',
  },
});