import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, ImageBackground } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MapPin, Calendar, Users, ArrowUpDown, Search, Tag } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function SearchTab() {
  const [tripType, setTripType] = useState<'one-way' | 'round-trip'>('round-trip');
  const [from, setFrom] = useState('Dhaka (DAC)');
  const [to, setTo] = useState('Dubai (DXB)');
  const [departDate, setDepartDate] = useState('Dec 25, 2024');
  const [returnDate, setReturnDate] = useState('Jan 2, 2025');
  const [passengers, setPassengers] = useState('1 Adult');

  const swapDestinations = () => {
    const temp = from;
    setFrom(to);
    setTo(temp);
  };

  const popularDestinations = [
    { city: 'Dubai', code: 'DXB', price: '৳45,000', image: 'https://images.pexels.com/photos/162031/dubai-tower-arab-khalifa-162031.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { city: 'Bangkok', code: 'BKK', price: '৳25,000', image: 'https://images.pexels.com/photos/2670273/pexels-photo-2670273.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { city: 'Singapore', code: 'SIN', price: '৳38,000', image: 'https://images.pexels.com/photos/2169434/pexels-photo-2169434.jpeg?auto=compress&cs=tinysrgb&w=400' },
    { city: 'Kuala Lumpur', code: 'KUL', price: '৳28,000', image: 'https://images.pexels.com/photos/1470405/pexels-photo-1470405.jpeg?auto=compress&cs=tinysrgb&w=400' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#1E40AF', '#3B82F6']}
        style={styles.header}
      >
        <Text style={styles.headerTitle}>AirBookBD</Text>
        <Text style={styles.headerSubtitle}>Find Your Perfect Flight</Text>
      </LinearGradient>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.searchCard}>
          <View style={styles.tripTypeContainer}>
            <TouchableOpacity
              style={[styles.tripTypeButton, tripType === 'one-way' && styles.tripTypeButtonActive]}
              onPress={() => setTripType('one-way')}
            >
              <Text style={[styles.tripTypeText, tripType === 'one-way' && styles.tripTypeTextActive]}>
                One Way
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.tripTypeButton, tripType === 'round-trip' && styles.tripTypeButtonActive]}
              onPress={() => setTripType('round-trip')}
            >
              <Text style={[styles.tripTypeText, tripType === 'round-trip' && styles.tripTypeTextActive]}>
                Round Trip
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.destinationContainer}>
            <TouchableOpacity style={styles.destinationInput}>
              <MapPin size={20} color="#6B7280" />
              <View style={styles.destinationTextContainer}>
                <Text style={styles.destinationLabel}>From</Text>
                <Text style={styles.destinationValue}>{from}</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.swapButton} onPress={swapDestinations}>
              <ArrowUpDown size={20} color="#1E40AF" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.destinationInput}>
              <MapPin size={20} color="#6B7280" />
              <View style={styles.destinationTextContainer}>
                <Text style={styles.destinationLabel}>To</Text>
                <Text style={styles.destinationValue}>{to}</Text>
              </View>
            </TouchableOpacity>
          </View>

          <View style={styles.dateContainer}>
            <TouchableOpacity style={[styles.dateInput, { flex: 1 }]}>
              <Calendar size={20} color="#6B7280" />
              <View style={styles.dateTextContainer}>
                <Text style={styles.dateLabel}>Departure</Text>
                <Text style={styles.dateValue}>{departDate}</Text>
              </View>
            </TouchableOpacity>

            {tripType === 'round-trip' && (
              <TouchableOpacity style={[styles.dateInput, { flex: 1, marginLeft: 12 }]}>
                <Calendar size={20} color="#6B7280" />
                <View style={styles.dateTextContainer}>
                  <Text style={styles.dateLabel}>Return</Text>
                  <Text style={styles.dateValue}>{returnDate}</Text>
                </View>
              </TouchableOpacity>
            )}
          </View>

          <TouchableOpacity style={styles.passengersInput}>
            <Users size={20} color="#6B7280" />
            <View style={styles.passengersTextContainer}>
              <Text style={styles.passengersLabel}>Passengers</Text>
              <Text style={styles.passengersValue}>{passengers}</Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={styles.searchButton}>
            <Search size={20} color="#FFFFFF" />
            <Text style={styles.searchButtonText}>Search Flights</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.popularSection}>
          <Text style={styles.sectionTitle}>Popular Destinations</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.popularScroll}>
            {popularDestinations.map((destination, index) => (
              <TouchableOpacity key={index} style={styles.popularCard}>
                <ImageBackground 
                  source={{ uri: destination.image }} 
                  style={styles.popularImage}
                  imageStyle={styles.popularImageStyle}
                >
                  <LinearGradient
                    colors={['transparent', 'rgba(0,0,0,0.7)']}
                    style={styles.popularOverlay}
                  >
                    <Text style={styles.popularCity}>{destination.city}</Text>
                    <Text style={styles.popularCode}>{destination.code}</Text>
                    <Text style={styles.popularPrice}>from {destination.price}</Text>
                  </LinearGradient>
                </ImageBackground>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.featuresSection}>
          <Text style={styles.sectionTitle}>Why Choose AirBookBD?</Text>
          <View style={styles.featuresGrid}>
            <View style={styles.featureCard}>
              <View style={styles.featureIcon}>
                <Search size={24} color="#1E40AF" />
              </View>
              <Text style={styles.featureTitle}>Easy Search</Text>
              <Text style={styles.featureDescription}>Find flights quickly with our smart search</Text>
            </View>
            <View style={styles.featureCard}>
              <View style={styles.featureIcon}>
                <Tag size={24} color="#059669" />
              </View>
              <Text style={styles.featureTitle}>Best Prices</Text>
              <Text style={styles.featureDescription}>Guaranteed lowest fares and exclusive deals</Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 24,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#E0E7FF',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  searchCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginTop: -20,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  tripTypeContainer: {
    flexDirection: 'row',
    marginBottom: 20,
    backgroundColor: '#F1F5F9',
    borderRadius: 12,
    padding: 4,
  },
  tripTypeButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  tripTypeButtonActive: {
    backgroundColor: '#FFFFFF',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  tripTypeText: {
    fontSize: 14,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
  },
  tripTypeTextActive: {
    color: '#1E40AF',
  },
  destinationContainer: {
    marginBottom: 20,
  },
  destinationInput: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  destinationTextContainer: {
    marginLeft: 12,
    flex: 1,
  },
  destinationLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 2,
  },
  destinationValue: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  swapButton: {
    position: 'absolute',
    right: 20,
    top: 50,
    backgroundColor: '#FFFFFF',
    padding: 8,
    borderRadius: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    zIndex: 1,
  },
  dateContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  dateInput: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  dateTextContainer: {
    marginLeft: 12,
  },
  dateLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 2,
  },
  dateValue: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  passengersInput: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#F8FAFC',
    borderRadius: 12,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: '#E2E8F0',
  },
  passengersTextContainer: {
    marginLeft: 12,
  },
  passengersLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#6B7280',
    marginBottom: 2,
  },
  passengersValue: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
  },
  searchButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#1E40AF',
    paddingVertical: 16,
    borderRadius: 12,
    elevation: 4,
    shadowColor: '#1E40AF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  searchButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: '#FFFFFF',
    marginLeft: 8,
  },
  popularSection: {
    marginTop: 32,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Inter-Bold',
    color: '#1F2937',
    marginBottom: 16,
  },
  popularScroll: {
    marginLeft: -20,
    paddingLeft: 20,
  },
  popularCard: {
    width: 160,
    height: 120,
    marginRight: 16,
    borderRadius: 12,
    overflow: 'hidden',
  },
  popularImage: {
    width: '100%',
    height: '100%',
  },
  popularImageStyle: {
    borderRadius: 12,
  },
  popularOverlay: {
    flex: 1,
    justifyContent: 'flex-end',
    padding: 12,
  },
  popularCity: {
    fontSize: 16,
    fontFamily: 'Inter-Bold',
    color: '#FFFFFF',
  },
  popularCode: {
    fontSize: 12,
    fontFamily: 'Inter-Medium',
    color: '#E0E7FF',
    marginBottom: 4,
  },
  popularPrice: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#34D399',
  },
  featuresSection: {
    marginBottom: 32,
  },
  featuresGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  featureCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    marginHorizontal: 4,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    alignItems: 'center',
  },
  featureIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#EFF6FF',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  featureTitle: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#1F2937',
    marginBottom: 4,
    textAlign: 'center',
  },
  featureDescription: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 16,
  },
});